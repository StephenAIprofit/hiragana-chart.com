# hiragana-chart.com

单页。主词 hiragana chart。46 个平假名、笔顺、点击读音。没有片假名。

## 部署

1. 把这个目录推到 GitHub，仓库名可用 hiragana-chart.com。
2. Vercel：Add New → Project → Import 这个仓库 → Deploy。没有环境变量。
3. Cloudflare 添加站点 hiragana-chart.com，免费套餐。把 Cloudflare 给的 2 个 NS 填到 Namecheap。
4. Namecheap：Domain List → Manage → Nameservers → Custom DNS。
5. Vercel 添加域名 hiragana-chart.com。Cloudflare SSL/TLS 选 Full (Strict)。
6. 主域名用不带 www 的。www 做 301。http 跳 https。
7. 打开 https://hiragana-chart.com/ 确认页面后，再提交 Google Search Console 和 sitemap。
