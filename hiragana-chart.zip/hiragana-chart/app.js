const ROWS = [
  ["あ", "a", "3 strokes: a short horizontal, a vertical with a hook, then the loop."],
  ["い", "i", "2 strokes: a left curve, then a shorter right curve."],
  ["う", "u", "2 strokes: a short top mark, then the long curve."],
  ["え", "e", "2 strokes: a horizontal, then the vertical that bends right."],
  ["お", "o", "3 strokes: horizontal, vertical with a hook, then the right curve."],
  ["か", "ka", "3 strokes: horizontal, vertical, then the right curve."],
  ["き", "ki", "4 strokes: two horizontals, a vertical, then the bottom hook."],
  ["く", "ku", "1 stroke: an angle opening right."],
  ["け", "ke", "3 strokes: left vertical, then two right strokes."],
  ["こ", "ko", "2 strokes: two horizontals, top then bottom."],
  ["さ", "sa", "3 strokes: horizontal, vertical, then the bottom curve."],
  ["し", "shi", "1 stroke: a curve falling left, then hooking up."],
  ["す", "su", "2 strokes: a horizontal with a vertical, then the loop."],
  ["せ", "se", "3 strokes: horizontal, vertical, then the bottom angle."],
  ["そ", "so", "1 stroke: a zigzag ending in a curve."],
  ["た", "ta", "4 strokes: horizontal, vertical hook, then two short strokes."],
  ["ち", "chi", "2 strokes: a short horizontal, then the long curve."],
  ["つ", "tsu", "1 stroke: a wave, like a small つ."],
  ["て", "te", "1 stroke: horizontal, then a long vertical curve."],
  ["と", "to", "2 strokes: a short top curve, then the corner."],
  ["な", "na", "4 strokes: horizontal, vertical, then two crossing curves."],
  ["に", "ni", "3 strokes: a left curve, then two horizontals."],
  ["ぬ", "nu", "2 strokes: a left curve, then a loop that crosses it."],
  ["ね", "ne", "2 strokes: a left curve, then the looped right stroke."],
  ["の", "no", "1 stroke: a spiral."],
  ["は", "ha", "3 strokes: vertical, then two strokes on the right."],
  ["ひ", "hi", "1 stroke: a loop that crosses itself."],
  ["ふ", "fu", "4 strokes: two short marks, then two curves."],
  ["へ", "he", "1 stroke: a peak, like a roof."],
  ["ほ", "ho", "4 strokes: vertical, two right strokes, then a bottom curve."],
  ["ま", "ma", "3 strokes: horizontal, vertical, then the loop."],
  ["み", "mi", "2 strokes: a small top curve, then a longer curve."],
  ["む", "mu", "3 strokes: a short curve, a long curve, then a crossing stroke."],
  ["め", "me", "2 strokes: a top curve, then the loop."],
  ["も", "mo", "3 strokes: a hook, then two horizontals."],
  ["や", "ya", "3 strokes: a short curve, a long curve, then a crossing stroke."],
  ["ゆ", "yu", "2 strokes: a right curve, then the left hook."],
  ["よ", "yo", "2 strokes: a horizontal, then the vertical curve."],
  ["ら", "ra", "2 strokes: a short top mark, then the curve."],
  ["り", "ri", "2 strokes: a left curve, then a right curve."],
  ["る", "ru", "1 stroke: a loop on the way down."],
  ["れ", "re", "2 strokes: a vertical, then the right curve."],
  ["ろ", "ro", "1 stroke: a vertical that ends in a loop."],
  ["わ", "wa", "2 strokes: a vertical hook, then the right curve."],
  ["を", "wo", "3 strokes: horizontal, vertical, then the loop."],
  ["ん", "n", "1 stroke: a curve that hooks up."]
];

const grid = document.querySelector("#grid");
const big = document.querySelector("#big");
const reading = document.querySelector("#reading");
const order = document.querySelector("#order");

function select(item, button) {
  document.querySelectorAll(".cell").forEach((el) => el.setAttribute("aria-pressed", "false"));
  button.setAttribute("aria-pressed", "true");
  big.textContent = item[0];
  reading.textContent = item[1];
  order.textContent = item[2];
  speak(item[0]);
}

function speak(text) {
  if (!window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text);
  utter.lang = "ja-JP";
  window.speechSynthesis.speak(utter);
}

ROWS.forEach((item) => {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "cell";
  button.setAttribute("aria-pressed", "false");
  button.innerHTML = `<div class="kana">${item[0]}</div><p class="romaji">${item[1]}</p><p class="strokes">${item[2].split(":")[0]}</p>`;
  button.addEventListener("click", () => select(item, button));
  grid.appendChild(button);
});

document.querySelector("#play").addEventListener("click", () => speak(big.textContent));
document.querySelector("#print").addEventListener("click", () => window.print());
select(ROWS[0], grid.querySelector(".cell"));
